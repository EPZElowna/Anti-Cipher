fx_version 'cerulean'
game 'gta5'


author '36lw'
description 'Anti-Backdoor'
version '1.0'

lua54 'yes'
server_script 'main.lua'
